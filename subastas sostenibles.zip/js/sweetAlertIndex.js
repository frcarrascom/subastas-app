swal.fire({
    title: "Una Subasta ha finalizado",
    text: "mira tus mensajes para mas informacion!",
    type: "warning",
    confirmButtonColor: '#3085d6',
    confirmButtonText: 'ok!',
});